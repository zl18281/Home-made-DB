1. Menu class is added to print the first, second and third level menus

2. UserInterface class use nested do---while loop to implement the menu function. Public functions/interfaces in class "Database" and "Table" are called to do the actual task of creating/drop database, create/drop table, inserting/deleting data, etc.
