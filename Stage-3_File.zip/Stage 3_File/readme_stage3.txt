This stage mainly adds the function of saving the table to files and reading data from files.

1. Reading a file concerns the process of storing the tokens to a 2D array according to each token's row and column positions. And the first line is treated as the attribute row, while the rest are stored into items row by row.

2. Wrtting to a file concerns the establishing output stream to this file and print to file line by line (within the same line, tokens are seperated by spaces and lines are seperated by "newline" character). This is consistent with the format needed by File Reading.

3. Up to this point, FileNotFound exception was not considered but was added later. 
