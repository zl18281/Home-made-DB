The class "Database" is added.

1. The main use of this class is to store the Tables into one entity. 

2. Tables can be created by providing field names and can be dropped. However, at this stage, the order for dropping tables is not fulfilled (not violating FK constriant).
