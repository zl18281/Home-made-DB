This Class function as a tuple of a table including the zeroth row (the attributes of a table).

1. An array list, with StringBuilder as its storing object type, is used to represent a tuple. 

2. The second constructor build a tuple with specified number of fields, setting the content of each field to an empty string.

3. Function "setField" receives the index of the field and candidate string as arguments and set the field of this index to this string.

3. Function "getField" receives an index and return the object(a StringBuilder) with this index, thus getting the conrresponding field.

4. Also, some other setter and getter methods are added, including obtaining the number of fields in a tuple.

5. The main design idea is providing some public interfaces for the upper class (Table) to access.
