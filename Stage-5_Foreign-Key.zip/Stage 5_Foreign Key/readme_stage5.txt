Part of Foreign Key function is fulfilled.

1. I used two HashMap to represent the FK relationship. One for storing all the Referred Table/Attibute pair and the other for linking the attribute in this table with that of the referred table.

2. FK constriant can be checked when inserting data, but deleting data while not violating FK constriant are fulfilled later. 
