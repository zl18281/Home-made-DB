This stage adds the class "Table" which acts as a Table (Grouping the attribute row and tuples into one). Some features might be missing but were implemented later (some issue came up later as developing went).

1. The property "feature" is a "Record" type to store the attributes. The "items" is an array list of "Record" type to store the data.

2. The Second Constructor initialise the table arributes and build a empty "bowl" for the data. 

3. The main public functions include those for adding/deleting a column, inserting/deleting a tuple, selecting a tuple and printing the table in a clean format. Other private functions are designed to assist the public functions.

note: Printing neatly is implemented here.
