Primary key function is added.

1. I used an array list to store PKs, thus composite PK is fulfilled.

2. Functions include assigning PK, checking PK constriant when inserting data, selecting a row by PK values.
