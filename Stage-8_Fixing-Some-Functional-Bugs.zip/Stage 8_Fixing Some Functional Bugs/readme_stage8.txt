This part mainly tackled the issue of FK constriant when deleting data and table.

Another hashmap is added to "Table" class to record those table/attribute pairs that refer this table. A table cannot be deleted until all the tables depending on this table are deleted. A record can not be deleted until all the records that depending on this record are deleted. Before deleting a data or a table, its record of dependency in the hashmap is deleted first.
