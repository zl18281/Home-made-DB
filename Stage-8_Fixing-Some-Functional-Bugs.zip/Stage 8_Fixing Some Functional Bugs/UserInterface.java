import java.util.*;

public class UserInterface {

    public static void main(String[] args) {
        ArrayList<Database> db = new ArrayList<Database>();
        boolean b = true;
        Menu m = new Menu();
        
        do {
            int i = 0;
            Scanner input = new Scanner(System.in);
            
            m.mainMenu();
            System.out.println("Input your choice:");
            i = input.nextInt();
            switch(i) {
                case 1: {
                    b = true;
                    if(db.size() == 0) {
                        System.out.println();
                        System.out.println("There is no database");
                        break;
                    }
                    System.out.println();
                    for(int j = 0; j < db.size(); j++) {
                        System.out.println((j + 1) + ". " + db.get(j).getName().toString() + "\n");
                    }
                    break;
                }
                case 2: {
                    b = true;
                    int k = 0;
                    boolean s = true;
                    
                    if(db.size() == 0) {
                        System.out.println("There is no database");
                        break;
                    }
                    System.out.println("Input database name:");
                    String temp = input.next();
                    Database choose = null;
                    
                    for(int t = 0; t < db.size(); t++) {
                        if(db.get(t).getName().equals(temp)) {
                            choose = db.get(t);
                        }
                    }
                    if(choose == null) {
                        System.out.println("Database does not exit !");
                        break;
                    }
                    System.out.println("\nAlter to database: \"" + choose.getName() + "\"");
                    do {
                        m.secondMenu(choose);
                        k = input.nextInt();
                        switch(k) {
                            case 1:{
                                s = true;
                                choose.showTables();
                                break;
                            }
                            case 2: {
                                s = true;
                                String [] y;
                                int cnt = 0;
                                
                                System.out.println("Input table name:");
                                String tempName = input.next();
                                System.out.println("Input fields (seperated by space):");
                                Scanner tempInput = new Scanner(System.in);
                                String tempField = tempInput.nextLine();
                                Scanner in = new Scanner(tempField);
                                while(in.hasNext()) {
                                    cnt++;
                                    in.next();
                                }
                                y = new String[cnt];
                                in = new Scanner(tempField);
                                int index = 0;
                                while(in.hasNext()) {
                                    y[index] = in.next();
                                    index++;
                                }
                                choose.addTable(tempName, y);
                                break;
                            }
                            case 3: {
                                s = true;
                                System.out.println("Input table name:");
                                String tableForRemove = input.next();
                                
                                Table tForRemove = choose.getTableByName(tableForRemove);
                                if(tForRemove == null) {
                                    System.out.println("Table does not exists !");
                                    break;
                                }
                                choose.dropTable(tableForRemove);
                                break;
                            }
                            case 4:{
                                s = true;
                                System.out.println("Input table name:");
                                String tempTableName = input.next();
                                Table tempTable = choose.getTableByName(tempTableName);
                                Scanner inputTwo = new Scanner(System.in);
                                if(tempTable == null) {
                                    break;
                                }
                                boolean u = true;
                                do {
                                    m.thirdMenu(tempTable);
                                    int l = inputTwo.nextInt();
                                    switch (l) {
                                        case 1: {
                                            u = true;
                                            tempTable.printTable();
                                            break;
                                        }
                                        case 2: {
                                            u = true;
                                            System.out.println("Input data for the following fields:");
                                            for(int w = 0; w < tempTable.getFields().getNumberOfFields(); w++) {
                                                System.out.print(tempTable.getFields().getField(w + 1) + " ");
                                            }
                                            System.out.println();
                                            Scanner inputFields = new Scanner(System.in);
                                            Record rTemp = new Record(tempTable.getFields().getNumberOfFields());
                                            for(int w = 0; w < tempTable.getFields().getNumberOfFields(); w++) {
                                                rTemp.setField(w + 1, inputFields.next());
                                            }
                                            tempTable.insertItem(rTemp);
                                            break;
                                        }
                                        case 3: {
                                            u = true;
                                            System.out.println("Input the index for the tuple:");
                                            tempTable.deleteItem(inputTwo.nextInt());
                                            break;
                                        }
                                        case 4: {
                                            u = true;
                                            System.out.println("Input the PK fields:");
                                            Scanner inputPkField = new Scanner(System.in);
                                            String PkFields = inputPkField.nextLine();
                                            Scanner inputPkFieldTokens = new Scanner(PkFields);
                                            int cnt = 0;
                                            while(inputPkFieldTokens.hasNext()) {
                                                cnt++;
                                                inputPkFieldTokens.next();
                                            }
                                            String[] PkTokens = new String[cnt];
                                            inputPkFieldTokens = new Scanner(PkFields);
                                            for(int p = 0; p < cnt; p++) {
                                                PkTokens[p] = inputPkFieldTokens.next();
                                            }
                                            tempTable.deleteItemByPk(PkTokens);
                                            break;
                                        }
                                        case 5: {
                                            u = true;
                                            Scanner inputALine = new Scanner(System.in);
                                            System.out.println("Input the Primary Key for the tuple:");
                                            String pKOfTuple = inputALine.nextLine();
                                            int cnt = 0;
                                            Scanner tempString = new Scanner(pKOfTuple);
                                            while(tempString.hasNext()) {
                                                cnt++;
                                                tempString.next();
                                            }
                                            String []pKToken = new String[cnt];
                                            Scanner newTempString = new Scanner(pKOfTuple);
                                            int z = 0;
                                            while(newTempString.hasNext()) {
                                                pKToken[z] = newTempString.next();
                                                z++;
                                            }
                                            Record tempRecord = tempTable.selectItemByPrimaryKey(pKToken);
                                            System.out.println("Input the field name:");
                                            String fieldName = inputALine.next();
                                            System.out.println("Input new value:");
                                            String newValue = inputALine.next();
                                            int indexForUpdating = -1;
                                            for(int x = 0; x < tempTable.getFields().getNumberOfFields(); x++) {
                                                if(tempTable.getFields().getField(x + 1).toString().equals(fieldName)) {
                                                    indexForUpdating = x;
                                                }
                                            }
                                            if(indexForUpdating != (-1)) {
                                                tempRecord.setField(indexForUpdating + 1, newValue);
                                            }
                                            break;
                                        }
                                        case 6: {
                                            u = true;
                                            Scanner inputPk = new Scanner(System.in);
                                            System.out.println("Input the PKs:");
                                            String tempPk = inputPk.nextLine();
                                            Scanner inputPkToken = new Scanner(tempPk);
                                            int arraySizeOfPk = 0;
                                            while(inputPkToken.hasNext()) {
                                                arraySizeOfPk++;
                                                inputPkToken.next();
                                            }
                                            String[] token = new String[arraySizeOfPk];
                                            inputPkToken = new Scanner(tempPk);
                                            for(int o = 0; o < arraySizeOfPk; o++) {
                                                token[o] = inputPkToken.next();
                                            }
                                            tempTable.assignPrimaryKey(token);
                                            break;
                                        }
                                        case 7: {
                                            u = true;
                                            Scanner inputRefTable = new Scanner(System.in);
                                            System.out.println("Input refernced table:");
                                            Table refTable = choose.getTableByName(inputRefTable.next());
                                            Scanner inputFk = new Scanner(System.in);
                                            System.out.println("Input fK");
                                            String fK = inputFk.next();
                                            System.out.println("Input referencing field:");
                                            Scanner inputFkHere = new Scanner(System.in);
                                            String fKHere = inputFkHere.next();
                                            tempTable.assignForeignKey(refTable, fKHere, fK);
                                            break;
                                        }
                                        case 8: {
                                            u = true;
                                            Scanner inputColumnForRemove = new Scanner(System.in);
                                            System.out.println("Input the name of a column for removing:");
                                            tempTable.alterTableDeleteColumn(inputColumnForRemove.next());
                                            break;
                                        }
                                        case 9: {
                                            u = true;
                                            Scanner inputColumnForAdd = new Scanner(System.in);
                                            System.out.println("Input the name of a column for adding:");
                                            tempTable.alterTableAddColumn(inputColumnForAdd.next());
                                            break;
                                        }
                                        case 10: {
                                            u = false;
                                            break;
                                        }
                                    }
                                }while(u);
                            }
                            break;
                            case 5: {
                                s = false;
                                break;
                            }
                        }
                    }while(s);
                    break;
                }
                case 3:{
                    b = true;
                    System.out.println("Input database name:");
                    String tempDbName = input.next();
                    db.add(new Database(tempDbName));
                    System.out.println();
                    System.out.println("Database \"" + tempDbName + "\" is created !");
                    break;
                }
                case 4:{
                    b = false;
                    break;
                }
            }
        } while(b);
    }
}
